package com.ebookfrenzy.myapplication

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.ebookfrenzy.myapplication.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {
   private lateinit var binding : ActivityMainBinding
  //  private val calculateTip = Double * .15
  //  , Double *.20, Double * .15

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)



         val tipAmount1 = 0.1
         val tipAmount2 = 0.15
         val tipAmount3 = 0.20

                      binding.calculateButton.setOnClickListener {
                          val billAmount = binding.billAmount.text.toString().toDouble()
                          //var tipAmount1 = binding.tipAmount.
                          val total = (billAmount * tipAmount1) + billAmount
                          val total2 = (billAmount * tipAmount2) + billAmount
                          val total3 = (billAmount * tipAmount3) + billAmount
                          binding.total.text = total.toString()
                          binding.total2.text = total2.toString()
                          binding.total3.text = total3.toString()
                         
                      }
                  }
               }






            //+ ((tipAmount1 / 100.0) + billAmount)


      //  binding.total.text = total.toString()
           // binding.total2.text = total2.toString()
      //  binding.total3.text = total3




      //  val billAmount = binding.tip.calculateButton
    //    val tipPercentage = when (calculateTip())
        //    val text = binding.billAmount.


       // if (binding.billAmount.text.isNotEmpty()) {
        //    val billAmount = binding.billAmount.text.toString().toFloat()










//  val billAmount = binding.billAmount.text.toString()
       //val cost = billAmount.toDouble()







    



